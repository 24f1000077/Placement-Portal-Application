import re
import io
from datetime import datetime, timedelta, timezone
from flask import Blueprint, request, jsonify, send_file
from werkzeug.security import generate_password_hash

from models import (
    db, User, Role, Branch,
    CompanyProfile, CompanyStatus,
    StudentProfile, StudentStatus,
    PlacementDrive, PlacementDriveStatus, drive_branches,
    Application, ApplicationStatus,
    InterviewSchedule, InterviewStatus, Placement,
)
from serializers import company_to_dict, student_to_dict, drive_to_dict, application_to_dict, interview_to_dict
from utils import role_required, error
from realtime import notify_application_update
from app import cache
# Reuses the company blueprint's drive-payload validation so admin-created drives are held to the exact same rules as company-created ones.
from services.company import validate_drive_payload

admin_bp = Blueprint('admin', __name__)

EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
PHONE_RE = re.compile(r'^\d{7,15}$')
# Application stages that are still "in play" and eligible for auto-rejection/withdrawal when their drive or company is cancelled/blacklisted.
ACTIVE_APPLICATION_STATUSES = [ApplicationStatus.APPLIED, ApplicationStatus.SHORTLISTED, ApplicationStatus.INTERVIEW, ApplicationStatus.OFFER]


def split_param(name):
    # Reads a comma-separated query string param into a list, dropping empty entries.
    raw = request.args.get(name, '')
    return [v for v in raw.split(',') if v]


@admin_bp.route('/overview', methods=['GET'])
@role_required('ADMIN')
def overview():
    # Returns headline counts for the admin dashboard landing page.
    return jsonify({
        'total_students': StudentProfile.query.count(),
        'total_companies_approved': CompanyProfile.query.filter_by(approval_status=CompanyStatus.APPROVED).count(),
        'total_drives_approved': PlacementDrive.query.filter_by(status=PlacementDriveStatus.APPROVED).count(),
    })


# ---- Companies ----

@admin_bp.route('/companies', methods=['GET'])
@role_required('ADMIN')
@cache.cached(timeout=60, query_string=True)
def list_companies():
    # Lists companies, filterable by name search and approval status; response is cached per distinct query string for 60 seconds.
    q = CompanyProfile.query.join(User)
    search = request.args.get('search', '').strip()
    if search:
        q = q.filter(CompanyProfile.company_name.ilike(f'%{search}%'))
    statuses = split_param('status')
    if statuses:
        q = q.filter(CompanyProfile.approval_status.in_([CompanyStatus[s] for s in statuses if s in CompanyStatus.__members__]))
    companies = q.order_by(CompanyProfile.id.desc()).all()
    return jsonify({'count': len(companies), 'results': [company_to_dict(c) for c in companies]})


@admin_bp.route('/companies', methods=['POST'])
@role_required('ADMIN')
def create_company():
    # Creates a company account directly as APPROVED (admin already vetted it, so there's no pending-review step to skip). Field validation mirrors public registration.
    data = request.get_json(force=True) or {}
    name = (data.get('name') or '').strip()
    email = (data.get('email') or '').strip().lower()
    password = data.get('password') or ''
    company_name = (data.get('company_name') or '').strip()
    hr_contact = (data.get('hr_contact') or '').strip()
    industry = (data.get('industry') or '').strip()
    website = (data.get('website') or '').strip()

    if not name or not email or not password or not company_name or not hr_contact:
        return error('Name, email, password, company name and HR contact number are required.')
    if not EMAIL_RE.match(email):
        return error('Please provide a valid email address.')
    if len(password) < 6:
        return error('Password must be at least 6 characters long.')
    if not PHONE_RE.match(hr_contact):
        return error('Please provide a valid HR contact number.')
    if User.query.filter_by(email=email).first():
        return error('An account with this email already exists.')

    user = User(name=name, role=Role.COMPANY, email=email, password=generate_password_hash(password), is_active=True)
    db.session.add(user)
    db.session.flush()

    profile = CompanyProfile(
        user_id=user.id,
        company_name=company_name,
        hr_contact=hr_contact,
        industry=industry or None,
        website=website or None,
        approval_status=CompanyStatus.APPROVED,
    )
    db.session.add(profile)
    db.session.commit()
    cache.clear()
    return jsonify(company_to_dict(profile)), 201


@admin_bp.route('/companies/<int:company_id>', methods=['PATCH'])
@role_required('ADMIN')
def update_company(company_id):
    # Updates any subset of a company's contact-person, email, and profile fields.
    company = CompanyProfile.query.get_or_404(company_id)
    data = request.get_json(force=True) or {}

    if 'name' in data and data['name'].strip():
        company.user.name = data['name'].strip()
    if 'email' in data and data['email'].strip():
        email = data['email'].strip().lower()
        if not EMAIL_RE.match(email):
            return error('Please provide a valid email address.')
        existing = User.query.filter(User.email == email, User.id != company.user_id).first()
        if existing:
            return error('An account with this email already exists.')
        company.user.email = email
    if 'company_name' in data:
        if not data['company_name'].strip():
            return error('Company name cannot be empty.')
        company.company_name = data['company_name'].strip()
    if 'hr_contact' in data:
        company.hr_contact = data['hr_contact'].strip() or None
    if 'industry' in data:
        company.industry = data['industry'].strip() or None
    if 'website' in data:
        company.website = data['website'].strip() or None

    db.session.commit()
    cache.clear()
    return jsonify(company_to_dict(company))


@admin_bp.route('/companies/<int:company_id>/approve', methods=['POST'])
@role_required('ADMIN')
def approve_company(company_id):
    # Moves a pending company to APPROVED, allowing it to log in and post drives.
    company = CompanyProfile.query.get_or_404(company_id)
    if company.approval_status != CompanyStatus.PENDING:
        return error('Only pending companies can be approved.')
    company.approval_status = CompanyStatus.APPROVED
    db.session.commit()
    cache.clear()
    return jsonify(company_to_dict(company))


@admin_bp.route('/companies/<int:company_id>/reject', methods=['POST'])
@role_required('ADMIN')
def reject_company(company_id):
    # Moves a pending company to REJECTED, permanently denying this registration.
    company = CompanyProfile.query.get_or_404(company_id)
    if company.approval_status != CompanyStatus.PENDING:
        return error('Only pending companies can be rejected.')
    company.approval_status = CompanyStatus.REJECTED
    db.session.commit()
    cache.clear()
    return jsonify(company_to_dict(company))


@admin_bp.route('/companies/<int:company_id>/blacklist', methods=['POST'])
@role_required('ADMIN')
def blacklist_company(company_id):
    # Blacklists a company, deactivates its login, cancels its open drives, and auto-rejects every application under it that hasn't already resulted in a placement.
    company = CompanyProfile.query.get_or_404(company_id)
    if company.approval_status != CompanyStatus.APPROVED:
        return error('Only approved companies can be blacklisted.')
    company.approval_status = CompanyStatus.BLACKLISTED
    company.user.is_active = False
    affected = []
    for drive in company.drives:
        if drive.status not in (PlacementDriveStatus.CANCELLED, PlacementDriveStatus.APPLICATIONS_CLOSED):
            drive.status = PlacementDriveStatus.CANCELLED
        for application in drive.applications:
            if application.status != ApplicationStatus.PLACED:
                application.status = ApplicationStatus.REJECTED
                application.feedback = 'Automatically rejected: the company was blacklisted.'
                affected.append(application)
    db.session.commit()
    cache.clear()
    for application in affected:
        notify_application_update(application)
    return jsonify(company_to_dict(company))


@admin_bp.route('/companies/<int:company_id>/whitelist', methods=['POST'])
@role_required('ADMIN')
def whitelist_company(company_id):
    # Restores a blacklisted company to APPROVED and reactivates its login.
    # Drives/applications rejected by the blacklist action are not automatically restored.
    company = CompanyProfile.query.get_or_404(company_id)
    if company.approval_status != CompanyStatus.BLACKLISTED:
        return error('Only blacklisted companies can be whitelisted.')
    company.approval_status = CompanyStatus.APPROVED
    company.user.is_active = True
    db.session.commit()
    cache.clear()
    return jsonify(company_to_dict(company))


# ---- Placement Drives ----

@admin_bp.route('/drives', methods=['GET'])
@role_required('ADMIN')
@cache.cached(timeout=60, query_string=True)
def list_drives():
    # Lists placement drives with search/company/status/skills/CGPA/branch/deadline filters; response is cached per distinct query string for 60 seconds.
    q = PlacementDrive.query.join(CompanyProfile)
    search = request.args.get('search', '').strip()
    if search:
        q = q.filter(PlacementDrive.job_title.ilike(f'%{search}%'))
    company_ids = split_param('company_ids')
    if company_ids:
        q = q.filter(PlacementDrive.company_id.in_([int(c) for c in company_ids]))
    statuses = split_param('status')
    if statuses:
        q = q.filter(PlacementDrive.status.in_([PlacementDriveStatus[s] for s in statuses if s in PlacementDriveStatus.__members__]))
    skills = request.args.get('skills', '').strip()
    if skills:
        q = q.filter(PlacementDrive.skills_required.ilike(f'%{skills}%'))
    min_cgpa = request.args.get('min_cgpa')
    if min_cgpa:
        q = q.filter(PlacementDrive.cgpa >= float(min_cgpa))
    branches = split_param('branches')
    if branches:
        q = q.join(drive_branches).join(Branch).filter(Branch.name.in_(branches))
    deadline_from = request.args.get('deadline_from')
    if deadline_from:
        q = q.filter(PlacementDrive.application_deadline >= datetime.fromisoformat(deadline_from))
    deadline_to = request.args.get('deadline_to')
    if deadline_to:
        q = q.filter(PlacementDrive.application_deadline < datetime.fromisoformat(deadline_to) + timedelta(days=1))
    drives = q.order_by(PlacementDrive.created_at.desc()).all()
    return jsonify({'count': len(drives), 'results': [drive_to_dict(d) for d in drives]})


@admin_bp.route('/drives', methods=['POST'])
@role_required('ADMIN')
def create_drive():
    # Creates a placement drive directly as APPROVED, linked to the company_id the admin picks. Uses the same field validation as a company creating its own drive.
    data = request.get_json(force=True) or {}
    company = CompanyProfile.query.get(data.get('company_id'))
    if not company:
        return error('Please select a valid company for this drive.')

    errors = validate_drive_payload(data)
    if errors:
        return error(' '.join(errors))

    branches = Branch.query.filter(Branch.id.in_(data['branch_ids'])).all()
    drive = PlacementDrive(
        company_id=company.id,
        job_title=data['job_title'].strip(),
        job_description=data.get('job_description'),
        location=data.get('location'),
        job_type=data.get('job_type'),
        application_deadline=datetime.fromisoformat(data['application_deadline']),
        cgpa=float(data['cgpa']),
        min_target_year=int(data['min_target_year']),
        max_target_year=int(data['max_target_year']),
        skills_required=data.get('skills_required'),
        experience_required=data.get('experience_required'),
        salary=float(data['salary']),
        benefits=data.get('benefits'),
        notes=data.get('notes'),
        status=PlacementDriveStatus.APPROVED,
        allowed_branches=branches,
    )
    db.session.add(drive)
    db.session.commit()
    cache.clear()
    return jsonify(drive_to_dict(drive)), 201


@admin_bp.route('/drives/<int:drive_id>', methods=['PATCH'])
@role_required('ADMIN')
def update_drive(drive_id):
    # Updates any subset of a drive's fields; only touches what's present in the payload.
    drive = PlacementDrive.query.get_or_404(drive_id)
    data = request.get_json(force=True) or {}

    for field in ['job_title', 'job_description', 'location', 'job_type',
                  'skills_required', 'experience_required', 'benefits', 'notes']:
        if field in data:
            setattr(drive, field, data[field])
    if 'cgpa' in data:
        try:
            cgpa = float(data['cgpa'])
        except (TypeError, ValueError):
            return error('Minimum CGPA must be a number.')
        if cgpa < 0 or cgpa > 10:
            return error('Minimum CGPA must be between 0.0 and 10.0.')
        drive.cgpa = cgpa
    if 'salary' in data:
        try:
            salary = float(data['salary'])
        except (TypeError, ValueError):
            return error('Salary must be a number.')
        if salary <= 0:
            return error('Salary must be a positive number.')
        drive.salary = salary
    if 'min_target_year' in data or 'max_target_year' in data:
        try:
            min_target_year = int(data.get('min_target_year', drive.min_target_year))
            max_target_year = int(data.get('max_target_year', drive.max_target_year))
        except (TypeError, ValueError):
            return error('Minimum and maximum graduation years must be numbers.')
        if min_target_year > max_target_year:
            return error('Minimum graduation year cannot be after maximum graduation year.')
        drive.min_target_year = min_target_year
        drive.max_target_year = max_target_year
    if 'application_deadline' in data:
        drive.application_deadline = datetime.fromisoformat(data['application_deadline'])
    if 'branch_ids' in data:
        drive.allowed_branches = Branch.query.filter(Branch.id.in_(data['branch_ids'])).all()

    db.session.commit()
    cache.clear()
    return jsonify(drive_to_dict(drive))


@admin_bp.route('/drives/<int:drive_id>/approve', methods=['POST'])
@role_required('ADMIN')
def approve_drive(drive_id):
    # Moves a pending drive to APPROVED, making it visible to eligible students.
    drive = PlacementDrive.query.get_or_404(drive_id)
    if drive.status != PlacementDriveStatus.PENDING:
        return error('Only pending drives can be approved.')
    drive.status = PlacementDriveStatus.APPROVED
    db.session.commit()
    cache.clear()
    return jsonify(drive_to_dict(drive))


@admin_bp.route('/drives/<int:drive_id>/reject', methods=['POST'])
@role_required('ADMIN')
def reject_drive(drive_id):
    # Moves a pending drive to REJECTED.
    drive = PlacementDrive.query.get_or_404(drive_id)
    if drive.status != PlacementDriveStatus.PENDING:
        return error('Only pending drives can be rejected.')
    drive.status = PlacementDriveStatus.REJECTED
    db.session.commit()
    cache.clear()
    return jsonify(drive_to_dict(drive))


@admin_bp.route('/drives/<int:drive_id>/close', methods=['POST'])
@role_required('ADMIN')
def close_drive(drive_id):
    # Stops new applications to an approved drive without cancelling it outright.
    drive = PlacementDrive.query.get_or_404(drive_id)
    if drive.status != PlacementDriveStatus.APPROVED:
        return error('Only approved drives can be closed.')
    drive.status = PlacementDriveStatus.APPLICATIONS_CLOSED
    db.session.commit()
    cache.clear()
    return jsonify(drive_to_dict(drive))


@admin_bp.route('/drives/<int:drive_id>/cancel', methods=['POST'])
@role_required('ADMIN')
def cancel_drive(drive_id):
    # Cancels an approved drive and auto-rejects every application still in progress on it.
    drive = PlacementDrive.query.get_or_404(drive_id)
    if drive.status != PlacementDriveStatus.APPROVED:
        return error('Only approved drives can be cancelled.')
    drive.status = PlacementDriveStatus.CANCELLED
    affected = []
    for application in drive.applications:
        if application.status in ACTIVE_APPLICATION_STATUSES:
            application.status = ApplicationStatus.REJECTED
            application.feedback = 'Automatically rejected: the placement drive was cancelled.'
            affected.append(application)
    db.session.commit()
    cache.clear()
    for application in affected:
        notify_application_update(application)
    return jsonify(drive_to_dict(drive))


@admin_bp.route('/drives/<int:drive_id>/extend-deadline', methods=['POST'])
@role_required('ADMIN')
def extend_deadline(drive_id):
    # Sets a new future deadline; re-opens the drive if it had been closed.
    drive = PlacementDrive.query.get_or_404(drive_id)
    if drive.status not in (PlacementDriveStatus.APPROVED, PlacementDriveStatus.APPLICATIONS_CLOSED):
        return error('Only approved or applications-closed drives can have their deadline extended.')
    data = request.get_json(force=True) or {}
    try:
        new_deadline = datetime.fromisoformat(data.get('application_deadline', ''))
    except ValueError:
        return error('Please provide a valid deadline date.')
    if new_deadline <= datetime.now(timezone.utc).replace(tzinfo=new_deadline.tzinfo):
        return error('The new deadline must be a future date.')
    drive.application_deadline = new_deadline
    if drive.status == PlacementDriveStatus.APPLICATIONS_CLOSED:
        drive.status = PlacementDriveStatus.APPROVED
    db.session.commit()
    cache.clear()
    return jsonify(drive_to_dict(drive))


# ---- Applications ----

@admin_bp.route('/applications', methods=['GET'])
@role_required('ADMIN')
def list_applications():
    # Lists applications across every company, filterable by student name, company, drive, and status; sorted by most recently applied first.
    q = Application.query.join(StudentProfile).join(PlacementDrive).join(CompanyProfile)
    search = request.args.get('search', '').strip()
    if search:
        q = q.join(User, StudentProfile.user_id == User.id).filter(User.name.ilike(f'%{search}%'))
    company_ids = split_param('company_ids')
    if company_ids:
        q = q.filter(PlacementDrive.company_id.in_([int(c) for c in company_ids]))
    drive_ids = split_param('drive_ids')
    if drive_ids:
        q = q.filter(Application.drive_id.in_([int(d) for d in drive_ids]))
    statuses = split_param('status')
    if statuses:
        q = q.filter(Application.status.in_([ApplicationStatus[s] for s in statuses if s in ApplicationStatus.__members__]))
    applications = q.order_by(Application.application_date.desc()).all()
    return jsonify({'count': len(applications), 'results': [application_to_dict(a, include_interviews=False) for a in applications]})


@admin_bp.route('/applications/<int:application_id>', methods=['GET'])
@role_required('ADMIN')
def get_application(application_id):
    # Returns full application detail, including its interviews and placement if any.
    application = Application.query.get_or_404(application_id)
    return jsonify(application_to_dict(application))


@admin_bp.route('/applications/<int:application_id>', methods=['PATCH'])
@role_required('ADMIN')
def update_application(application_id):
    # Lets an admin correct an application's status, feedback, or offer details directly.
    application = Application.query.get_or_404(application_id)
    data = request.get_json(force=True) or {}

    if 'status' in data:
        if data['status'] not in ApplicationStatus.__members__:
            return error('Invalid application status.')
        new_status = ApplicationStatus[data['status']]
        # A placement record is created once when an offer is accepted; moving the
        # application away from PLACED would orphan that record and let a later
        # accept-offer attempt collide with it (Placement.application_id is unique).
        if application.placement and new_status != ApplicationStatus.PLACED:
            return error('This application already has a placement record and cannot be moved out of Placed.')
        application.status = new_status
    if 'feedback' in data:
        application.feedback = data['feedback'] or None
    if 'offered_salary' in data:
        try:
            application.offered_salary = float(data['offered_salary']) if data['offered_salary'] not in (None, '') else None
        except (TypeError, ValueError):
            return error('Offered salary must be a number.')
    if 'offered_joining_date' in data:
        try:
            application.offered_joining_date = (
                datetime.fromisoformat(data['offered_joining_date']).date() if data['offered_joining_date'] else None
            )
        except ValueError:
            return error('Offered joining date must be a valid date.')

    db.session.commit()
    cache.clear()
    notify_application_update(application)
    return jsonify(application_to_dict(application))


# ---- Students ----

@admin_bp.route('/students', methods=['GET'])
@role_required('ADMIN')
@cache.cached(timeout=60, query_string=True)
def list_students():
    # Lists students with name/email search, branch/graduation-year/CGPA-range/placement filters; response is cached per distinct query string for 60 seconds.
    q = StudentProfile.query.join(User)
    search = request.args.get('search', '').strip()
    if search:
        q = q.filter(db.or_(User.name.ilike(f'%{search}%'), User.email.ilike(f'%{search}%')))
    branches = split_param('branches')
    if branches:
        q = q.join(Branch, StudentProfile.branch_id == Branch.id).filter(Branch.name.in_(branches))
    grad_years = split_param('graduation_years')
    if grad_years:
        q = q.filter(StudentProfile.graduation_year.in_([int(y) for y in grad_years]))
    min_cgpa = request.args.get('min_cgpa')
    if min_cgpa:
        q = q.filter(StudentProfile.cgpa >= float(min_cgpa))
    max_cgpa = request.args.get('max_cgpa')
    if max_cgpa:
        q = q.filter(StudentProfile.cgpa <= float(max_cgpa))
    placement_status = request.args.get('placement_status', '').strip().upper()
    if placement_status == 'PLACED':
        q = q.filter(StudentProfile.placements.any())
    elif placement_status == 'UNPLACED':
        q = q.filter(~StudentProfile.placements.any())
    students = q.order_by(StudentProfile.id.desc()).all()
    return jsonify({'count': len(students), 'results': [student_to_dict(s) for s in students]})


@admin_bp.route('/students/<int:student_id>', methods=['PATCH'])
@role_required('ADMIN')
def update_student(student_id):
    # Updates any subset of a student's account and profile fields.
    student = StudentProfile.query.get_or_404(student_id)
    data = request.get_json(force=True) or {}

    if 'name' in data and data['name'].strip():
        student.user.name = data['name'].strip()
    if 'email' in data and data['email'].strip():
        email = data['email'].strip().lower()
        if not EMAIL_RE.match(email):
            return error('Please provide a valid email address.')
        existing = User.query.filter(User.email == email, User.id != student.user_id).first()
        if existing:
            return error('An account with this email already exists.')
        student.user.email = email
    if 'contact_number' in data:
        student.contact_number = data['contact_number'].strip() or None
    if 'cgpa' in data:
        try:
            cgpa = float(data['cgpa'])
        except (TypeError, ValueError):
            return error('CGPA must be a number.')
        if cgpa < 0 or cgpa > 10:
            return error('CGPA must be between 0.0 and 10.0.')
        student.cgpa = cgpa
    if 'graduation_year' in data:
        student.graduation_year = int(data['graduation_year'])
    if 'branch_id' in data:
        branch = Branch.query.get(data['branch_id'])
        if not branch:
            return error('Please select a valid branch.')
        student.branch_id = branch.id
    if 'skills' in data:
        student.skills = data['skills']
    if 'experience' in data:
        student.experience = data['experience']

    db.session.commit()
    cache.clear()
    return jsonify(student_to_dict(student))


@admin_bp.route('/students/<int:student_id>/blacklist', methods=['POST'])
@role_required('ADMIN')
def blacklist_student(student_id):
    # Blacklists a student, deactivates their login, and withdraws every application of theirs that's still in progress.
    student = StudentProfile.query.get_or_404(student_id)
    if student.approval_status != StudentStatus.APPROVED:
        return error('Only active students can be blacklisted.')
    student.approval_status = StudentStatus.BLACKLISTED
    student.user.is_active = False
    for application in student.applications:
        if application.status in ACTIVE_APPLICATION_STATUSES:
            application.status = ApplicationStatus.WITHDRAWN
    db.session.commit()
    cache.clear()
    return jsonify(student_to_dict(student))


@admin_bp.route('/students/<int:student_id>/whitelist', methods=['POST'])
@role_required('ADMIN')
def whitelist_student(student_id):
    # Restores a blacklisted student to APPROVED and reactivates their login.
    student = StudentProfile.query.get_or_404(student_id)
    if student.approval_status != StudentStatus.BLACKLISTED:
        return error('Only blacklisted students can be whitelisted.')
    student.approval_status = StudentStatus.APPROVED
    student.user.is_active = True
    db.session.commit()
    cache.clear()
    return jsonify(student_to_dict(student))


@admin_bp.route('/students/<int:student_id>/resume', methods=['GET'])
@role_required('ADMIN')
def download_student_resume(student_id):
    # Streams the student's current live resume as a PDF.
    student = StudentProfile.query.get_or_404(student_id)
    if not student.resume:
        return error('No resume uploaded yet.', 404)
    return send_file(io.BytesIO(student.resume), mimetype='application/pdf', download_name='resume.pdf')


@admin_bp.route('/applications/<int:application_id>/resume', methods=['GET'])
@role_required('ADMIN')
def download_application_resume(application_id):
    # Streams the resume snapshot taken when this application was submitted, not the student's current profile resume.
    application = Application.query.get_or_404(application_id)
    if not application.snapshot_resume:
        return error('No resume uploaded yet.', 404)
    return send_file(io.BytesIO(application.snapshot_resume), mimetype='application/pdf', download_name='resume.pdf')


@admin_bp.route('/applications/<int:application_id>/offer-letter', methods=['GET'])
@role_required('ADMIN')
def download_application_offer_letter(application_id):
    # Streams the offer letter PDF the company uploaded for this application.
    application = Application.query.get_or_404(application_id)
    if not application.offer_letter:
        return error('No offer letter uploaded yet.', 404)
    return send_file(io.BytesIO(application.offer_letter), mimetype='application/pdf', download_name='offer_letter.pdf')


# ---- Interviews ----

@admin_bp.route('/interviews', methods=['GET'])
@role_required('ADMIN')
def list_interviews():
    # Lists every scheduled interview campus-wide, filterable by drive/company or student name and sortable by scheduled date/time.
    q = (InterviewSchedule.query
         .join(Application).join(StudentProfile).join(User, StudentProfile.user_id == User.id)
         .join(PlacementDrive).join(CompanyProfile))
    drive_or_company = request.args.get('search_drive_company', '').strip()
    if drive_or_company:
        q = q.filter(db.or_(
            PlacementDrive.job_title.ilike(f'%{drive_or_company}%'),
            CompanyProfile.company_name.ilike(f'%{drive_or_company}%'),
        ))
    student_name = request.args.get('student_name', '').strip()
    if student_name:
        q = q.filter(User.name.ilike(f'%{student_name}%'))
    order = InterviewSchedule.scheduled_date_time.asc() if request.args.get('sort') == 'oldest' else InterviewSchedule.scheduled_date_time.desc()
    interviews = q.order_by(order).all()
    results = []
    # Adds student/drive/company names for display, since the base serializer doesn't join them.
    for interview in interviews:
        application = interview.application
        payload = interview_to_dict(interview)
        payload.update({
            'student_name': application.student.user.name,
            'job_title': application.drive.job_title,
            'company_name': application.drive.company.company_name,
        })
        results.append(payload)
    return jsonify({'count': len(results), 'results': results})


@admin_bp.route('/interviews/<int:interview_id>', methods=['PATCH'])
@role_required('ADMIN')
def update_interview(interview_id):
    # Updates any subset of an interview's schedule, contact, notes, and status.
    interview = InterviewSchedule.query.get_or_404(interview_id)
    data = request.get_json(force=True) or {}

    if 'scheduled_date_time' in data:
        try:
            interview.scheduled_date_time = datetime.fromisoformat(data['scheduled_date_time'])
        except (TypeError, ValueError):
            return error('Scheduled date/time must be a valid datetime.')
    if 'meeting_link' in data:
        interview.meeting_link = data['meeting_link'] or None
    if 'interviewer_name' in data:
        interview.interviewer_name = data['interviewer_name'] or None
    if 'notes' in data:
        interview.notes = data['notes'] or None
    if 'feedback' in data:
        interview.feedback = data['feedback'] or None
    if 'status' in data:
        if data['status'] not in InterviewStatus.__members__:
            return error('Invalid interview status.')
        interview.status = InterviewStatus[data['status']]

    db.session.commit()
    cache.clear()
    notify_application_update(interview.application)
    return jsonify(interview_to_dict(interview))
